import React from "react";
import "./styles.css";

function ToDoItem(props) {
  return (
    <li className={`todo-item ${props.done ? "done" : ""}`}>
      <input
        type="checkbox"
        checked={props.done}
        onChange={() => props.onToggle(props.id)}
      />

      <span className="todo-text">{props.text}</span>

      <button className="delete-btn" onClick={() => props.onDelete(props.id)}>
        ❌
      </button>
    </li>
  );
}

export default ToDoItem;
