import React, { useState } from "react";
import ToDoItem from "./ToDoItem";
import "./styles.css";

function App() {
  const [inputText, setInputText] = useState("");
  const [items, setItems] = useState([]);

  function handleChange(event) {
    setInputText(event.target.value);
  }

  function addItem() {
    if (inputText.trim() === "") return;
    setItems((prevItems) => [...prevItems, { text: inputText, done: false }]);
    setInputText("");
  }

  function deleteItem(id) {
    setItems((prevItems) => prevItems.filter((_, index) => index !== id));
  }

  function toggleDone(id) {
    setItems((prevItems) =>
      prevItems.map((item, index) =>
        index === id ? { ...item, done: !item.done } : item
      )
    );
  }

  function clearAll() {
    setItems([]);
  }

  return (
    <div className="container">
      <div className="heading">
        <h1>To-Do List</h1>
      </div>

      <div className="form">
        <input onChange={handleChange} type="text" value={inputText} />
        <button className="btn" onClick={addItem}>
          <span>Add</span>
        </button>
      </div>

      {items.length > 0 && (
        <button className="btn clear-btn" onClick={clearAll}>
          <span>Clear All</span>
        </button>
      )}

      <ul>
        {items.map((todoItem, index) => (
          <ToDoItem
            key={index}
            id={index}
            text={todoItem.text}
            done={todoItem.done}
            onToggle={toggleDone}
            onDelete={deleteItem}
          />
        ))}
      </ul>
    </div>
  );
}

export default App;
